package Pruebas;

import org.openqa.selenium.By;

public class HomePage {
private By empleos = By.x

     "//header//div//li//a[text()= 'Empleos']";



}
