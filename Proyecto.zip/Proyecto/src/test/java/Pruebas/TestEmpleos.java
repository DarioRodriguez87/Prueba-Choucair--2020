package Pruebas;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import web.pom.HomePage;
import web.utilities.UtlWebActions;

public class TestEmpleos {

	private static UtlWebActions actions;

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\DARIO CUELLAR\\Desktop\\Prueba Analista de pruebas\\Proyecto\\src\\main\\resources\\drvers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		HomePage home = new HomePage(driver);
		UtlWebActions actions = new UtlWebActions(driver);
		home.navigate();
		home.clicEmpleos();
		actions.maximize();
		actions.terminate();
	}
}
