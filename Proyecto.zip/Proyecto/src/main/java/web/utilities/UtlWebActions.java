package web.utilities;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

public class UtlWebActions {

	private static WebDriver driver;

	public UtlWebActions(WebDriver driver) {
		UtlWebActions.driver = driver;
	}

	public boolean clic(By object) {
		try {
			WebElement element = waitForElementToBeClickable(object, 10);
			element.click();
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public WebElement waitForElementToBeClickable(By objectname, long seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		try {
			return wait.until(new Function<WebDriver, WebElement>() {

				public WebElement apply(WebDriver driver) {
					WebElement element = driver.findElement(objectname);
					if (element.isDisplayed() && element.isEnabled()) {
						return element;
					} else {
						return null;
					}
				}
			});
		} catch (TimeoutException e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean navigateTo(String host) {
		try {
			driver.get(host);
			return true;
		} catch (Exception e) {
			e.getStackTrace();
			return false;
		}
	}

	public void terminate() {
		driver.close();
		driver.quit();
	}

	public void maximize() {
		driver.manage().window().maximize();
	}
}
