package web.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import web.utilities.UtlWebActions;

public class HomePage {

	private UtlWebActions actions;
	private WebDriver driver;
	private By empleos = By.xpath("//header//div//li//a[text()= 'Empleos']");

	public HomePage(WebDriver driver) {
		this.actions = new UtlWebActions(driver);
	}

	public boolean clicEmpleos() {
		return actions.clic(empleos);
	}

	public void navigate() {
		actions.navigateTo("https://www.choucairtesting.com");
	}
}
